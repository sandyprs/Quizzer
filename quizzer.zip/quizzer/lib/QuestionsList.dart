import 'package:quizzer/Questions.dart';

class QustionsList {
  List<Questions> qList = [
    // Questions("1 + 2 ?", "A. 3", "B. 6", "C. 2", "D. 8", "a"),
    // Questions("5 + 2 ?", "A. 3", "B. 6", "C. 7", "D. 8", "c"),
    // Questions("7 + 2 ?", "A. 3", "B. 9", "C. 2", "D. 8", "b"),

    Questions(
        "1. It is the 74th Independence Day this year which means: ",
        "(a) India has achieved 73 years of freedom",
        "(b) India has achieved 74 years of freedom",
        "(c) India has achieved 72 years of freedom",
        "(d) India has achieved 73 as well as 74 years of freedom",
        "A"),
    Questions(
        "2. Which among the following is/are true regarding the ratio of the national flag?",
        "(a) The ratio of the length to the height of the flag shall be 3:2",
        "(b) The ratio of the length to the width of the flag shall be 3:2",
        "(c) The ratio of the length to the height of the flag shall be 2:3",
        "(d) Both (a) and (b)",
        "D"),
    Questions(
        "3. On the Independence Day, the Prime Minister of India hoists our tricolour flag at:",
        "(a) the Purana Qila, Delhi",
        "(b) the Red Fort, Old Delhi",
        "(c) the Red Fort, Agra",
        "(d) the India Gate, New Delhi",
        "B"),
    Questions(
        "4. Who among the following was the Prime Minister of Britain at the time of Independence?",
        "(a) Lord Mountbatten",
        "(b) Winston Churchill",
        "(c) Clement Attlee",
        "(d) Ramsay MacDonald",
        "C"),
    Questions(
        "5. Who among the following was the first Governor-General of new Dominions of India?",
        "(a) Lord Mountbatten",
        "(b) C. Rajgopalchari",
        "(c) Dr. BR Amdedkar",
        "(d) Dr. Rajendra Prasad",
        "A"),
    Questions(
        "6. The famous quote \"a tryst with destiny\" is given by",
        "(a) Dr. BR Ambedkar",
        "(b) Pt. Jawaharlal Nehru",
        "(c) Mahatma Gandhi",
        "(d) Abdul Kalam Azad",
        "B"),
    Questions(
        "7. Which among the following Plan was known as the partition plan?",
        "(a) Macaulay Plan ",
        "(b) Atlee Announcement",
        "(c) Montagu-Chelmsford Reforms",
        "(d) Mountbatten Plan",
        "D"),
    Questions(
        "8. Which of the following are the extremist leaders?",
        "(a) Lala Lajpat Rai",
        "(b) Bal Gangadhar Tilak",
        "(c) Bipin Chandra Pal",
        "(d) All of the above",
        "D"),
    Questions(
        "9. Who presided the 1905 Congress session in Banaras?",
        "(a) Gopal Krishan Gokhale",
        "(b)  Dadabhai Naroji",
        "(c) Bal Gangadhar Tilak",
        "(d) Aurobindo Ghosh",
        "A"),
    Questions(
        "10. When Jallianwala Bagh Massacre took place?",
        "(a) 10 April, 1917",
        "(b) 13 April, 1918",
        "(c) 9 April, 1916",
        "(d) 13 April, 1919",
        "D")
  ];
  int currentQ = 0;
  bool finished = false;

  bool isFinished() {
    return finished;
  }

  void getNextQuestion() {
    currentQ++;
    if (currentQ > qList.length - 1) {
      finished = true;
    }
  }

  void reset() {
    currentQ = 0;
    finished = false;
  }

  String getQ() {
    return qList[currentQ].question;
  }

  String getop1() {
    return qList[currentQ].option1;
  }

  String getop2() {
    return qList[currentQ].option2;
  }

  String getop3() {
    return qList[currentQ].option3;
  }

  String getop4() {
    return qList[currentQ].option4;
  }

  String getans() {
    return qList[currentQ].ans;
  }
}

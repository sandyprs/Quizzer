class Questions {
  String question;
  String option1;
  String option2;
  String option3;
  String option4;
  String ans;

  Questions(
      String q, String o1, String o2, String o3, String o4, String ans) {
    this.question = q;
    this.option1 = o1;
    this.option2 = o2;
    this.option3 = o3;
    this.option4 = o4;
    this.ans = ans;

  }
}

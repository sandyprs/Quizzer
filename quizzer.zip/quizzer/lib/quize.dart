import 'package:audioplayers/audio_cache.dart';
import 'package:flutter/material.dart';
import 'package:quizzer/QuestionsList.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

int score = 0;

class Quize extends StatefulWidget {
  @override
  _QuizeState createState() => _QuizeState();
}

class _QuizeState extends State<Quize> {
  var qList = QustionsList();
  var opAColor = Colors.blue;
  var opBColor = Colors.blue;
  var opCColor = Colors.blue;
  var opDColor = Colors.blue;

  void checkAnswar(String ans) {
    var rightColor = Colors.green;
    var wrongColor = Colors.red;
    setState(() {
      if (ans == qList.getans().toUpperCase()) {
        score++;
        var player = AudioCache();
        player.play('right.wav');
        switch (ans) {
          case 'A':
            opAColor = rightColor;

            break;

          case 'B':
            opBColor = rightColor;

            break;

          case 'C':
            opCColor = rightColor;

            break;

          case 'D':
            opDColor = rightColor;

            break;

          default:
        }
      } else {
        var player = AudioCache();
        player.play('wrong.aiff');
        switch (qList.getans().toUpperCase()) {
          case 'A':
            opAColor = rightColor;

            break;

          case 'B':
            opBColor = rightColor;

            break;

          case 'C':
            opCColor = rightColor;

            break;

          case 'D':
            opDColor = rightColor;

            break;

          default:
        }

        switch (ans) {
          case 'A':
            opAColor = wrongColor;

            break;

          case 'B':
            opBColor = wrongColor;

            break;

          case 'C':
            opCColor = wrongColor;

            break;

          case 'D':
            opDColor = wrongColor;

            break;

          default:
        }
      }
    });
  }

  void next() {
    setState(() {
      qList.getNextQuestion();
      opAColor = Colors.blue;
      opBColor = Colors.blue;
      opCColor = Colors.blue;
      opDColor = Colors.blue;
      if (qList.isFinished()) {
        Alert(
          context: context,
          title: "Finished",
          desc: 'End of quize.\n Your score is $score',
          type: AlertType.info, 
        ).show();
        qList.reset();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text('Quizzer'),
        backgroundColor: Colors.black12,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child:
            Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Expanded(
            flex: 20,
            child: Center(
              child: Text(
                qList.getQ(),
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25.0,color: Colors.white),
              ),
            ),
          ),
          SizedBox(
            height: 2,
          ),
          optionKey(qList.getop1(), 'A', opAColor),
          SizedBox(
            height: 2,
          ),
          optionKey(qList.getop2(), 'B', opBColor),
          SizedBox(
            height: 2,
          ),
          optionKey(qList.getop3(), 'C', opCColor),
          SizedBox(
            height: 2,
          ),
          optionKey(qList.getop4(), 'D', opDColor),
          SizedBox(
            height: 2,
          ),
          Expanded(
            flex: 5,
            child: FlatButton(
              onPressed: () => next(),
              child: Text(
                'Next',
                style: TextStyle(
                  fontSize: 18.0,
                  color: Colors.white,
                ),
              ),
              color: Colors.blue,
            ),
          )
        ]),
      ),
    );
  }

  Expanded optionKey(String opt, String opId, Color colour) {
    return Expanded(
      flex: 5,
      child: FlatButton(
        onPressed: () => checkAnswar(opId),
        child: Text(
          opt,
          style: TextStyle(
            fontSize: 18.0,
            color: Colors.white,
          ),
        ),
        color: colour,
      ),
    );
  }
}
